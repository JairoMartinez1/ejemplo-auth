# protoripo2_dashborad_prebeta1b

segundo prototipo en base de las especificaciones del cliente

![image](https://github.com/samuelzazueta/protoripo2_dashborad/assets/82922454/6215f699-2f09-45c3-be0e-f3b8b02e69f6)

imagen de el modelo actual de la base de datos:
![Clase UML](https://github.com/samuelzazueta/protoripo2_dashborad/assets/82922454/e68c1b14-a8ec-4686-a2ab-7ab845a92fa5)

estado actual de la paguina:
![image](https://github.com/samuelzazueta/protoripo2_dashborad/assets/82922454/b468741c-84da-44c6-9d1a-227d0d029a75)



